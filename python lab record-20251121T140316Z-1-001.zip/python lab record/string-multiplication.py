s = "Good"
print(s * 3)
