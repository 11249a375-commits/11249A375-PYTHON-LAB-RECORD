fname ="sai teja"
iname ="karanam"

print("string concatenation:",fname+iname)
print("fname*4:",fname*4)
print("s is present in fname:",'s'in fname)
print("s  is present in fname:",'s'in fname)
print("slicing of fname:",fname[5:7])
print("s is not present in fname:",'s'not in iname)
   