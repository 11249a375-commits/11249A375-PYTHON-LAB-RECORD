s = 'GoodMorning'
for i in s:
  print(i)
