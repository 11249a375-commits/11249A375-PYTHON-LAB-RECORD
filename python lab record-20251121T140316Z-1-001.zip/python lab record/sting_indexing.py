s = 'GoodMorning'
print(s[0])
print(s[2])
print(s[4])
print(s[len(s) - 1])
print(len(s))
