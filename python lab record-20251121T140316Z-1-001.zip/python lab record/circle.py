pi = 3.14
radius=float(input("enter the radius of circle:"))
area = pi*(radius**2)
print("The area of the circle is:",area)