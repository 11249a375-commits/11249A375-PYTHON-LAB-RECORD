list1 =[1,2,3,4,5]
print("printing list1")
print("______")
for i in range(0,5):
    print(f"element present at index{i}={list1[i]}")
    print()

list1 =["sai teja","charan","achyuth","anirudh","puneth"]
print("printing list2")
print("______")
for i in range (0,5):
    print(f"element present at index{i}={list1[i]}")

list1 =["sai",1,2.3,"sai teja",2*3]
print("printing list3")
print("______")
for i in range (0,5):
    print(f"element present at index{i}={list1[i]}")
