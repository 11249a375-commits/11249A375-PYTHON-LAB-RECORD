days = float(input("Enter the number of days: "))

hours = days * 24
minutes = hours * 60
seconds = minutes * 60

print(f"{days} days is equal to:")
print(f"{hours} hours")
print(f"{minutes} minutes")
print(f"{seconds} seconds")
