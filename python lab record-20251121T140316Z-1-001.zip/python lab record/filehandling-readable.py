f = open("file1.txt", "r")
print(f.readable())
