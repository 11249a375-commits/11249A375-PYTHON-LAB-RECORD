s = "Good" + "-" + "Morning"
print(s)

