s = 'GoodMorning'
print(len(s))
print(min(s))
print(max(s))
print(sorted(s))
print(sorted(s, reverse = True))
