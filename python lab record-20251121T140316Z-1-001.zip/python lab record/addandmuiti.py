# Ask the user to enter three numbers
a = int(input("Enter the first number: "))
b = int(input("Enter the second number: "))
c = int(input("Enter the third number: "))
sum_ab = a + b
result = sum_ab * c
print("The result is:", result)
