total_bill = float(input("Enter the total price of the bill: "))
num_diners = int(input("Enter the number of diners: "))
amount_each = total_bill / num_diners
print("Each person must pay:", amount_each)
