name = "john"
def print_name(name):
   print("Hi",name)
name = input("Enter the name?")
print_name(name)