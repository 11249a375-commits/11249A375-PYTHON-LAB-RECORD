country_capitals ={"United States": "Washington D.C.", "England": "London", "Germany":"Berlin", "Canada": "Ottawa "  }
print(len(country_capitals))
print(country_capitals)
country_capitals["Italy"] = "Rome"
print(country_capitals)
del country_capitals["Germany"]
print(country_capitals)
country_capitals.clear()
print(country_capitals)
