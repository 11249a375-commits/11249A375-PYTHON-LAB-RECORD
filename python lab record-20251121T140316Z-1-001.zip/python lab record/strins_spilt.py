str1 = "Java is a programming language"
str2 = str1.split()
print(str1)
print(str2)

str2 = str1.split(sep=',')
print(str1)
print(str2)
