def displayMsg(name):
  print("Hi "+name)