print("Hello" == "World")
print("Hello" != "World")

print("Mumbai" > "Pune")
print("Goa" < "Indore")
