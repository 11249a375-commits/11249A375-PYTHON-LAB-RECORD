x = ["Rose","Lotus"]
print('is value present?',"Rose" in x)
print('is value not present?',"Riya" in x)
a =["Rose","Lotus"]
b =["Rose","Lotus"]
c =a
print(a is c)
print(a is not c)
print(a is b)
print (a is not b)
print(a == b)
print(a != b)