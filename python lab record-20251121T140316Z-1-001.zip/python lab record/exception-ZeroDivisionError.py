n = 10
try:
    res = n / 0
except ZeroDivisionError:
    print("Can't be divided by zero!")
