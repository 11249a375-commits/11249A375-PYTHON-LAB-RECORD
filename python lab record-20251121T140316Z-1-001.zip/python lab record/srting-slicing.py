s = 'Good Morning'
print(s[1: 4])
print(s[1: ])
print(s[: 4])
print(s[: ])
print(s[0: 8: 3])
print(s[::-1])
