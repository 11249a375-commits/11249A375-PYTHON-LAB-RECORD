def main():
        obj1 = open("file2.txt","w")
        obj1.write("i love food \n")
        obj1.write("IN india\n ")
        obj1.write("south side food is ultimatted \n")
        obj1.close()
main()
