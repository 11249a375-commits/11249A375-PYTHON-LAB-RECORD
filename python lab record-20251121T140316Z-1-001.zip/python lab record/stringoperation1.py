
a="Hello"
b="World"
c=b+a
print(c) # WorldHello
c=b+"\t "+a # World Hello

print(c)
