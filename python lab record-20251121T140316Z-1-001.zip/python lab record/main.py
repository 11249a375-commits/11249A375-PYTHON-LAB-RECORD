a = int(input("Enter the first number"))
b = int(input("Enter the second number"))
print("Sum = ",sum(a,b))