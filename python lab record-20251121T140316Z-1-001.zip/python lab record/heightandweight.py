a=int(input("enter the height:"))
b=int(input("enter the width:"))
for i in range(a):
      print("#"*b)