s = "Its Raining Outside"
print(s.upper())
print(s.lower()) 
print(s.swapcase())
