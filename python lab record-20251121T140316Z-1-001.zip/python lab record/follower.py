a=int(input("enter the total no.of follower you have:"))
b=int(input("enter the no.of follower you have:"))
c=a*(b/10)
print("total exitimated reach is:",c)
