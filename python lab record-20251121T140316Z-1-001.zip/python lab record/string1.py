
s = 'Good Morning'
print (s)
 #conversion
a = 99 #int
print(str(a))
