kg = float(input("Enter the weight in kilograms: "))
pounds = kg * 2204
print(f"{kg} kilograms is equal to {pounds} pounds.")
