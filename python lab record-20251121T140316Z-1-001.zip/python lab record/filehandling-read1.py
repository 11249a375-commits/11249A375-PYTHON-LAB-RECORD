f = open("file1.txt", "r")
print(f.read(-1))
print(f.read(3))