try :
     print("Hello world"
except SyntaxError:
	print("Verify the line try section properly closed or not")
