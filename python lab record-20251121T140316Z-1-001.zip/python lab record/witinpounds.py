weight =float(input("Enter you weight:"))
weight =weight * 2.20462
print(f"weight in pouns:{weight}")