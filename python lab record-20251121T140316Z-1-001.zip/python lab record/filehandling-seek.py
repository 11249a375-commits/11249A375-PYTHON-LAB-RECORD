f = open("file1.txt", "r")
f.seek(9)
print(f.readline())
