s = 'GoodMorning'
print(s[-1])
print(s[-2])
