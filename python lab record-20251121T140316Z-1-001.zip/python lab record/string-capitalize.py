s = "its raining outside"
print(s.capitalize()) 
print(s.title())
