s = "Its Raining Outside"
print(s.count("i"))
print(s.count("ing"))
