s = 'GoodMorning'
if 'M' in s:
  print('true')
