a = 1
total = 0

while a <= 10:
    total += a
    a += 1

print("Sum =", total)
