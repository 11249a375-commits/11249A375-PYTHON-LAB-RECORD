a=input("enter your first name")
b=input("enter your last name")
print ("hello",a,b)