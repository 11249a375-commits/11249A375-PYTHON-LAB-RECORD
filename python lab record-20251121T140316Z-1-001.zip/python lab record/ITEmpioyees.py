def getITnames():
    List=["John","David","Nick","Martin"]
    return List;