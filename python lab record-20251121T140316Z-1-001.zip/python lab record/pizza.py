slices_start = int(input("How many slices of pizza did you start with? "))
slices_eaten = int(input("How many slices have you eaten? "))
slices_left = slices_start - slices_eaten
print(f"You have {slices_left} slices left.")


