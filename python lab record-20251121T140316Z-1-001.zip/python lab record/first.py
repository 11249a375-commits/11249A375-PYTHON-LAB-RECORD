a=input("enter you first name")
print("hello",a)