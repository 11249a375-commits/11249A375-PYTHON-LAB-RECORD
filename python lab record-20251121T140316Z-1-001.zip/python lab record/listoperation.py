my_list = ['p','r','o','g','r','a','m','m','e']
print(my_list[2:5])
print(my_list[5:])
print(my_list[:])
list1 = [10, 15, 11, 65, 30]
list1.insert(1,80)
print('INSERTED ELEMENT IN THE LISTS  :', list1)
list1.sort()
print('SORTED ELEMENT IN THE LIST IS :', list1)
list1.reverse()
print('REVERSED ELEMENT IN THE LIST IS :',list1.pop(3,))
print('REMOVED ELEMENT IN THE LIST IS :', list1)
print('LARGEST ELEMENT IN THE LIST IS :',max(list1))
print('SMALLEST ELEMENT IN THE LIST IS :', min(list1))
