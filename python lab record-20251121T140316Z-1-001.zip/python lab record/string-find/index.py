s = "Its Raining Outside"
print(s.find("ing"))
print(s.index("ing"))
print(s.find("down"))

