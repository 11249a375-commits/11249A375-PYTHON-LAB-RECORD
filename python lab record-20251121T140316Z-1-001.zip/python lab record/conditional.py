a =int(input("enter a:"))
b =int(input("enter b:"))
c =int(input("enter c:"))

if a>b and a>c:
    print(a,"is bigger form given numbers")
elif b>c and b>a:
    print(b,"is bigger form given numbers")
else:
    print(c,"is bigger form given numbers")