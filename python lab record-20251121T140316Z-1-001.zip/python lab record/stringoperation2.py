
str1 = "Hello"
str2 = " Hello"
print(str1 is str2 )
print(str1 is not  str2 )
print(str1*3)
print(str1+str2)
print(str1[4])
print(str1[2:4])
print('w' in str1)
print('wo' not in str2)
print(r'Hello\n world')
print("The string str1 : %s"%(str1))
