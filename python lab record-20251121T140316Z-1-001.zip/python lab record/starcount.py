nights = [20, 35, 25, 40]
total = sum(nights)
print("Total Stars Counted =", total)
